#define LUA_api_func(name, number_of_arguments) Number lua_##name (lua_State* state){\
	if(lua_gettop(state) != (number_of_arguments)) {\
		error:\
		lua_pop(state, lua_gettop(state));\
		return 0;\
	}\

#define end }

/*
LUA_api_func(length, 1)
	lua_pushnumber(state, lua_getn(state, 1));
	return 1;
end*/

static int luaB_next (lua_State *L) {
  luaL_checktype(L, 1, LUA_TTABLE);
  lua_settop(L, 2);  // create a 2nd argument if there isn't one
  if (lua_next(L, 1))
    return 2;
  else {
    lua_pushnil(L);
    return 1;
  }
}

static int pairscont (lua_State *L, int status, lua_KContext k) {
  (void)L; (void)status; (void)k;  // unused
  return 3;
}

static int luaB_pairs (lua_State *L) {
  luaL_checkany(L, 1);
  if (luaL_getmetafield(L, 1, "__pairs") == LUA_TNIL) {  // no metamethod?
    lua_pushcfunction(L, luaB_next);  // will return generator,
    lua_pushvalue(L, 1);  // state,
    lua_pushnil(L);  // and initial value
  }
  else {
    lua_pushvalue(L, 1);  // argument 'self' to metamethod
    lua_callk(L, 1, 3, 0, pairscont);  // get 3 values from metamethod
  }
  return 3;
}
/*
LUA_api_func(pairs, 1)
	//lua_pushstring(state, lua_typename(state, lua_type(state, 1)));
	//return 1;

	if(luaL_getmetafield(L, 1, "__pairs") == LUA_TNIL) {  // no metamethod?
		lua_pushcfunction(L, luaB_next);  // will return generator,
		lua_pushvalue(L, 1);  // state,
		lua_pushnil(L);  // and initial value
	}
	else {
		lua_pushvalue(L, 1);  // argument 'self' to metamethod
		lua_callk(L, 1, 3, 0, pairscont);  // get 3 values from metamethod
	}

	return 3;
end*/

LUA_api_func(gettype, 1)
	lua_pushstring(state, lua_typename(state, lua_type(state, 1)));
	return 1;
end

LUA_api_func(require, 1)
	Byte* file_name;

	file_name = lua_tostring(state, 1);
	lua_pop(state, 1);

	if(luaL_dofile(state, file_name)) {
		print("%s\n", lua_tostring(state, -1));
		lua_pop(state, 1);
	}

	return lua_gettop(state);
end


//------------ Time ---------------
LUA_api_func(get_tick_count, 0)
	lua_pushnumber(state, GetTickCount());

	return 1;
end

LUA_api_func(get_time, 0)
	System_Time time;
	
	GetLocalTime(&time);
	
	lua_newtable(state);
	
	lua_pushstring(state, "year");
	lua_pushnumber(state, time.year);
	lua_settable(state, 1);
	
	lua_pushstring(state, "month");
	lua_pushnumber(state, time.month);
	lua_settable(state, 1);
	
	lua_pushstring(state, "day_of_week");
	lua_pushnumber(state, time.day_of_week);
	lua_settable(state, 1);
	
	lua_pushstring(state, "day");
	lua_pushnumber(state, time.day);
	lua_settable(state, 1);
	
	lua_pushstring(state, "hour");
	lua_pushnumber(state, time.hour);
	lua_settable(state, 1);
	
	lua_pushstring(state, "minute");
	lua_pushnumber(state, time.minute);
	lua_settable(state, 1);
	
	lua_pushstring(state, "second");
	lua_pushnumber(state, time.second);
	lua_settable(state, 1);
	
	lua_pushstring(state, "millisecond");
	lua_pushnumber(state, time.millisecond);
	lua_settable(state, 1);

	return 1;
end


//------------ Process ------------

LUA_api_func(create_process, 1)
	Number16*            command;
	Process_Information* process_info;
	Number               status;

	command = convert_utf8_to_unicode(lua_tostring(state, 1));
	lua_pop(state, 1);

	Sturtup_Info startup_info = {.size = sizeof(Sturtup_Info)};
	process_info = lua_newuserdata(state, sizeof(Process_Information));
	status = CreateProcessW(0, command, 0, 0, 0, 0, 0, 0, &startup_info, process_info);
	free_memory(command);
	
	if(!status) {
		return 0;
	}

	return 1;
end

LUA_api_func(wait_process, 1)
	Process_Information* process_info;

	process_info = lua_touserdata(state, 1);
	lua_pop(state, 1);

	WaitForSingleObject(process_info->process, 0xFFFFFFFF);

	return 0;
end

LUA_api_func(get_process_exit_code, 1)
	Process_Information* process_info;
	Number32             exit_code;

	process_info = lua_touserdata(state, 1);
	lua_pop(state, 1);

	GetExitCodeProcess(process_info->process, &exit_code);
	lua_pushnumber(state, exit_code);

	return 1;
end

LUA_api_func(terminate_process, 2)
	Process_Information* process_info;
	Number               exit_code;

	process_info = lua_touserdata(state, 1);
	exit_code = lua_tonumber(state, 2);
	lua_pop(state, 2);

	TerminateProcess(process_info->process, exit_code);

	return 0;
end

LUA_api_func(destroy_process, 1)
	Process_Information* process_info;

	process_info = lua_touserdata(state, 1);
	lua_pop(state, 1);

	CloseHandle(process_info->process);
	CloseHandle(process_info->thread);

	return 0;
end

LUA_api_func(sleep, 1)
	Number milliseconds;
	
	milliseconds = lua_tonumber(state, 1);
	Sleep(milliseconds);

	return 0;
end


//------------ Console ------------
LUA_api_func(get_console_reader, 0)
	Byte** input;

	input = lua_newuserdata(state, sizeof(Byte*));
	*input = GetStdHandle(STD_INPUT_HANDLE);

	return 1;
end

LUA_api_func(get_console_writer, 0)
	Byte** output;

	output = lua_newuserdata(state, sizeof(Byte*));
	*output = GetStdHandle(STD_OUTPUT_HANDLE);

	return 1;
end


LUA_api_func(read_from_console, 0)
	Byte** input;

	input = lua_newuserdata(state, sizeof(Byte*));
	*input = GetStdHandle(STD_INPUT_HANDLE);

	return 1;
end

LUA_api_func(write_in_console, 0)
	Byte** input;

	input = lua_newuserdata(state, sizeof(Byte*));
	*input = GetStdHandle(STD_INPUT_HANDLE);

	return 1;
end

LUA_api_func(print_string, 1)
	print_utf8(lua_tostring(state, 1));

	return 0;
end

LUA_api_func(print_number, 1)
	print("%f", lua_tonumber(state, 1));

	return 0;
end

/*
static void print_spaces(Number number_of_spaces)
{
	while(number_of_spaces) {
		print("    ");
		--number_of_spaces;
	}
}

static void print_lua_value(Lua_State* state, Number index_in_stack, Number level, Boolean need_spaces)
{
	Byte*             string;
	Rational_Number64 number;

	if(need_spaces) {
		print_spaces(level);
	}

	switch(lua_type(state, index_in_stack)) {
		case LUA_NIL:
			print("nil");
			break;

		case LUA_NUMBER:
			number = lua_tonumber(state, index_in_stack);
			
			if((Number)number == number) {
				print("%d", (Number)number);
			}
			else {
				print("%f", number);
			}
			break;

		case LUA_STRING:
			string = lua_tostring(state, index_in_stack);
			print(string);
			break;

		case LUA_TABLE: {
			Boolean table_is_empty = 1;
			print("{");

			lua_pushnil(state);
			while(lua_next(state, index_in_stack) != 0) {
				table_is_empty = 0;
				print("\n");
				print_lua_value(state, lua_gettop(state) - 1, level + 1, 1);
				print(" = ");
				print_lua_value(state, lua_gettop(state), level + 1, 0);

				lua_remove(state, -1);
			}

			if(!table_is_empty) {
				print("\n");
				print_spaces(level);
			}

			print("}");
			break;
		}

		case LUA_FUNCTION:
			print("function");
			break;

		case LUA_USERDATA:
			print("userdata");
			break;

		default:
			print("неизвестный тип %d", lua_type(state, index_in_stack));
	}
}


Number lua_print(Lua_State* state)
{
	Number number_of_arguments;

	number_of_arguments = lua_gettop(state);

	while(number_of_arguments) {
		print_lua_value(state, 1, 0, 1);

		lua_remove(state, 1);
		--number_of_arguments;
	}

	print("\n");

	return 0;
}*/


//------------ File ---------------
#include <file.c>

LUA_api_func(open_file, 1)
	Byte* file_name;
	File* file;

	file_name = lua_tostring(state, -1);
	lua_pop(state, 1);

	file = lua_newuserdata(state, sizeof(File));
	*file = open_file(file_name);

	if(!*file) {
		goto error;
	}

	return 1;
end

LUA_api_func(close_file, 1)
	File* file;

	file = lua_touserdata(state, 1);
	lua_pop(state, 1);

	close_file(*file);

	return 0;
end

typedef struct {
	Number64 creation;
	Number64 last_access;
	Number64 last_write;
}
Full_File_Time;

LUA_api_func(get_file_time, 1)
	File*           file;
	Full_File_Time* file_time;

	file = lua_touserdata(state, 1);
	lua_pop(state, 1);
	
	file_time = lua_newuserdata(state, sizeof(Full_File_Time));
	GetFileTime(*file, &file_time->creation, &file_time->last_access, &file_time->last_write);

	return 1;
end

LUA_api_func(set_file_time, 2)
	File*           file;
	Full_File_Time* file_time;

	file = lua_touserdata(state, 1);
	file_time = lua_touserdata(state, 2);
	lua_pop(state, 2);

	SetFileTime(*file, &file_time->creation, &file_time->last_access, &file_time->last_write);

	return 0;
end

void on_find_lua_file(lua_State* state, Byte* file_name, Boolean is_directory, Number32 size_low, Number32 size_high, Number index)
{
	lua_pushnumber(state, index + 1);
	lua_newtable(state);
	
	lua_pushstring(state, "name");
	lua_pushstring(state, file_name);
	lua_settable(state, 3);
	
	lua_pushstring(state, "is_directory");
	if(is_directory)
		lua_pushnumber(state, 1);
	else
		lua_pushnil(state);
	lua_settable(state, 3);
	
	lua_settable(state, 1);
}

LUA_api_func(find_files, 1)
	Byte* find_path;
	
	find_path = lua_tostring(state, 1);
	lua_pop(state, 1);
	lua_newtable(state);
	find_files(find_path, &on_find_lua_file, state);

	return 1;
end


//------------ graphics -----------
#include <graphics.c>


LUA_api_func(get_main_display, 1)
	Number display_index;
	Byte** display;
	
	display_index = lua_tonumber(state, 1);
	display = lua_newuserdata(state, sizeof(Byte*));
	*display = get_main_display(display_index);

	return 1;
end

LUA_api_func(create_display3D, 1)
	Byte** display;
	Byte** display3D;
	
	display = lua_touserdata(state, 1);
	display3D = lua_newuserdata(state, sizeof(Byte*));
	*display3D = create_display3D(*display);

	return 1;
end

LUA_api_func(begin_draw_3D, 2)
	Byte** display;
	Byte** display3D;
	
	display = lua_touserdata(state, 1);
	display3D = lua_touserdata(state, 2);
	begin_draw_3D(*display, *display3D);

	return 0;
end

LUA_api_func(end_draw_3D, 1)
	Byte** display;
	
	display = lua_touserdata(state, 1);
	end_draw_3D(*display);

	return 0;
end

LUA_api_func(destroy_display3D, 1)
	Byte** display;
	
	display = lua_touserdata(state, 1);
	destroy_display3D(*display);

	return 0;
end

#include <Windows/opengl32.c>

LUA_api_func(gl_clear, 0)
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	return 0;
end

LUA_api_func(gl_begin_triangles, 0)
	glBegin(GL_TRIANGLES);

	return 0;
end

LUA_api_func(gl_end, 0)
	glEnd();

	return 0;
end

LUA_api_func(gl_color, 3)
	double r;
	double g;
	double b;

	r = lua_tonumber(state, 1);
	g = lua_tonumber(state, 2);
	b = lua_tonumber(state, 3);
	glColor3f(r, g, b);

	return 0;
end

LUA_api_func(gl_vertex, 3)
	double x;
	double y;
	double z;
	
	x = lua_tonumber(state, 1);
	y = lua_tonumber(state, 2);
	z = lua_tonumber(state, 3);
	glVertex3f(x, y, z);

	return 0;
end

LUA_api_func(gl_normal, 3)
	double x;
	double y;
	double z;
	
	x = lua_tonumber(state, 1);
	y = lua_tonumber(state, 2);
	z = lua_tonumber(state, 3);
	glNormal3f(x, y, z);

	return 0;
end

LUA_api_func(gl_load_identity, 0)
	glLoadIdentity();

	return 0;
end

LUA_api_func(gl_translate, 3)
	double x;
	double y;
	double z;
	
	x = lua_tonumber(state, 1);
	y = lua_tonumber(state, 2);
	z = lua_tonumber(state, 3);
	glTranslatef(x, y, z);

	return 0;
end

LUA_api_func(gl_rotate, 4)
	double angle;
	double x;
	double y;
	double z;
	
	angle = lua_tonumber(state, 1);
	x = lua_tonumber(state, 2);
	y = lua_tonumber(state, 3);
	z = lua_tonumber(state, 4);
	glRotatef(angle, x, y, z);

	return 0;
end

LUA_api_func(gl_scale, 3)
	double x;
	double y;
	double z;
	
	x = lua_tonumber(state, 1);
	y = lua_tonumber(state, 2);
	z = lua_tonumber(state, 3);
	glScalef(x, y, z);

	return 0;
end


//------------ window -------------
#include <window.c>


Boolean handle_messages(Window* parameters)
{
	lua_State* state;
	Number     handler_ref;

	state = parameters->argument1;
	handler_ref = parameters->argument2;

	lua_rawgeti(state, LUA_REGISTRYINDEX, handler_ref);

	lua_pushnumber(state, parameters->message_type);
	lua_pushnumber(state, parameters->parameter1);
	lua_pushnumber(state, (Number)parameters->parameter2 & 0xFFFF);
	lua_pushnumber(state, ((Number)parameters->parameter2 >> 16) & 0xFFFF);

	lua_call(state, 4, 0);

	return 0;
}


LUA_api_func(create_window, 2)
	Window* parent;
	Window* window;
	Number  handler_ref;
	
	parent = lua_touserdata(state, 1);

	lua_topointer(state, 2);
	handler_ref = luaL_ref(state, LUA_REGISTRYINDEX);

	window = lua_newuserdata(state, sizeof(Window));
	window->parent = parent;
	window->handler = &handle_messages;
	window->argument1 = state;
	window->argument2 = handler_ref;
	initialize_window(window);

	return 1;
end

LUA_api_func(set_window_name, 2)
	Window* window;
	Byte*   name;
	
	window = lua_touserdata(state, 1);
	name = lua_tostring(state, 2);
	set_window_name(window, name);

	return 0;
end

LUA_api_func(set_window_position, 5)
	Window* window;
	Number  x;
	Number  y;
	Number  width;
	Number  height;
	
	window = lua_touserdata(state, 1);
	x = lua_tonumber(state, 2);
	y = lua_tonumber(state, 3);
	width = lua_tonumber(state, 4);
	height = lua_tonumber(state, 5);
	set_window_position(window, x, y, width, height);

	return 0;
end

LUA_api_func(get_window_position, 1)
	Window* window;
	Number  x;
	Number  y;
	Number  width;
	Number  height;
	
	window = lua_touserdata(state, 1);
	get_window_position(window, &x, &y, &width, &height);
	lua_pushnumber(state, x);
	lua_pushnumber(state, y);
	lua_pushnumber(state, width);
	lua_pushnumber(state, height);

	return 4;
end

LUA_api_func(get_window_client_position, 1)
	Window* window;
	Number  x;
	Number  y;
	Number  width;
	Number  height;
	
	window = lua_touserdata(state, 1);
	get_window_client_position(window, &x, &y, &width, &height);
	lua_pushnumber(state, x);
	lua_pushnumber(state, y);
	lua_pushnumber(state, width);
	lua_pushnumber(state, height);

	return 4;
end

LUA_api_func(show_window, 1)
	Window* window;

	window = lua_touserdata(state, 1);
	show_window(window);

	return 0;
end

LUA_api_func(show_maximized_window, 1)
	Window* window;

	window = lua_touserdata(state, 1);
	show_maximized_window(window);

	return 0;
end

LUA_api_func(show_fullscreen_window, 1)
	Window* window;

	window = lua_touserdata(state, 1);
	show_fullscreen_window(window);

	return 0;
end

LUA_api_func(hide_window, 1)
	Window* window;
	
	window = lua_touserdata(state, 1);
	hide_window(window);

	return 0;
end

LUA_api_func(redraw_window, 1)
	Window* window;
	
	window = lua_touserdata(state, 1);
	redraw_window(window);

	return 0;
end

LUA_api_func(pop_window_message, 0)
	lua_pushnumber(state, pop_window_message());

	return 1;
end

LUA_api_func(get_window_display, 1)
	Window* window;
	Byte**  display;
	
	window = lua_touserdata(state, 1);
	display = lua_newuserdata(state, sizeof(Byte*));
	*display = get_window_display(window);

	return 1;
end

LUA_api_func(begin_window_draw, 1)
	Window* window;
	Byte**  display;
	
	window = lua_touserdata(state, 1);
	display = lua_newuserdata(state, sizeof(Byte*));
	*display = begin_window_draw(window);

	return 1;
end

LUA_api_func(end_window_draw, 1)
	Window* window;
	
	window = lua_touserdata(state, 1);
	end_window_draw(window);

	return 0;
end

LUA_api_func(destroy_window, 1)
	Window* window;
	
	window = lua_touserdata(state, 1);
	deinitialize_window(window);

	return 0;
end


LUA_api_func(create_button, 1)
	Window* window;
	Byte**  button;
	
	window = lua_touserdata(state, 1);
	button = lua_newuserdata(state, sizeof(Byte*));
	*button = create_button(window);

	return 1;
end

LUA_api_func(set_button_text, 2)
	Byte** button;
	Byte*  text;
	
	button = lua_touserdata(state, 1);
	text = lua_tostring(state, 2);
	set_button_text(*button, text);

	return 0;
end



LUA_api_func(draw_rectangle, 6)
	Byte** display;
	Number x;
	Number y;
	Number width;
	Number height;
	Number color;
	
	display = lua_touserdata(state, 1);
	x = lua_tonumber(state, 2);
	y = lua_tonumber(state, 3);
	width = lua_tonumber(state, 4);
	height = lua_tonumber(state, 5);
	color = lua_tonumber(state, 6);
	draw_rectangle(*display, x, y, width, height, color);

	return 0;
end

LUA_api_func(draw_text, 5)
	Byte** display;
	Byte*  text;
	Number x;
	Number y;
	Number color;
	
	display = lua_touserdata(state, 1);
	text = lua_tostring(state, 2);
	x = lua_tonumber(state, 3);
	y = lua_tonumber(state, 4);
	color = lua_tonumber(state, 5);
	draw_text(*display, text, x, y, color);

	return 0;
end

LUA_api_func(calculate_text_size, 2)
	Byte** display;
	Byte*  text;
	Number width;
	Number height;
	
	display = lua_touserdata(state, 1);
	text = lua_tostring(state, 2);
	calculate_text_size(*display, text, &width, &height);
	lua_pushnumber(state, width);
	lua_pushnumber(state, height);

	return 2;
end


#define lua_register_api_func(name) {lua_pushcfunction(state, &lua_##name); lua_setfield(state, 1, #name); }//lua_pop(state, 1);}


void register_lua_api(lua_State* state)
{
	//lua_register(state, "length", &lua_length);
	lua_register(state, "pairs", &luaB_pairs);
	lua_register(state, "type", &lua_gettype);
	lua_register(state, "require", &lua_require);

	
	lua_newtable(state);
	
	lua_register_api_func(get_tick_count);
	lua_register_api_func(get_time);

	lua_register_api_func(create_process);
	lua_register_api_func(wait_process);
	lua_register_api_func(get_process_exit_code);
	lua_register_api_func(terminate_process);
	lua_register_api_func(destroy_process);
	lua_register_api_func(sleep);

	lua_register_api_func(get_console_reader);
	lua_register_api_func(get_console_writer);
	lua_register_api_func(print_string);
	lua_register_api_func(print_number);
	//lua_register_api_func(print);
	
	lua_register_api_func(open_file);
	lua_register_api_func(close_file);
	lua_register_api_func(get_file_time);
	lua_register_api_func(set_file_time);
	lua_register_api_func(find_files);

	lua_register_api_func(get_main_display);
	lua_register_api_func(create_display3D);
	lua_register_api_func(begin_draw_3D);
	lua_register_api_func(end_draw_3D);
	lua_register_api_func(destroy_display3D);
	lua_register_api_func(gl_clear);
	lua_register_api_func(gl_begin_triangles);
	lua_register_api_func(gl_end);
	lua_register_api_func(gl_color);
	lua_register_api_func(gl_vertex);
	lua_register_api_func(gl_normal);
	lua_register_api_func(gl_load_identity);
	lua_register_api_func(gl_translate);
	lua_register_api_func(gl_rotate);
	lua_register_api_func(gl_scale);
	
	lua_register_api_func(create_window);
	lua_register_api_func(set_window_name);
	lua_register_api_func(set_window_position);
	lua_register_api_func(get_window_position);
	lua_register_api_func(get_window_client_position);
	lua_register_api_func(show_window);
	lua_register_api_func(show_maximized_window);
	lua_register_api_func(show_fullscreen_window);
	lua_register_api_func(hide_window);
	lua_register_api_func(redraw_window);
	lua_register_api_func(destroy_window);
	lua_register_api_func(get_window_display);
	lua_register_api_func(begin_window_draw);
	lua_register_api_func(end_window_draw);
	lua_register_api_func(pop_window_message);
	
	lua_register_api_func(create_button);
	lua_register_api_func(set_button_text);
	
	lua_register_api_func(draw_rectangle);
	lua_register_api_func(draw_text);
	lua_register_api_func(calculate_text_size);

	lua_setglobal(state, "api");
	
	/*lua_register(state, "print", &lua_print);

	lua_register(state, "open_file", &lua_open_file);
	lua_register(state, "close_file", &lua_close_file);
	lua_register(state, "get_file_time", &lua_get_file_time);
	lua_register(state, "set_file_time", &lua_set_file_time);*/
	
	
	//lua_dobuffer(state, lua_api_code, sizeof(lua_api_code), "");
	//lua_dobuffer(state, lua_reactive_code, sizeof(lua_reactive_code), "");
	//lua_dobuffer(state, lua_program_code, sizeof(lua_program_code), "");
	
	//lua_dofile(state, "api.lua");
	//lua_dofile(state, "reactive.lua");
}