#include <lua.h>
#include <lauxlib.h>

#include <types.c>
#include <string.c>
#include "api.c"


void add_lua_arguments(lua_State* state, Byte** arguments, Number number_of_arguments)
{
	Number i;
	Byte*  utf8_argument;
	
	lua_newtable(state);

	for(i = 1; i < number_of_arguments; ++i) {
		utf8_argument = get_utf8_argument(arguments[i]);

		lua_pushnumber(state, i);
		lua_pushstring(state, utf8_argument);
		lua_settable(state, 1);

		free_memory(utf8_argument);
	}

	lua_setglobal(state, "arguments");
}


Number main(Number number_of_arguments, Byte** arguments)
{
	Byte*      script_path;
	lua_State* state;

	if(number_of_arguments > 1) {
		script_path = arguments[1];
	}
	else {
		script_path = "main.lua";
	}
	
	state = luaL_newstate();
	
	if(!state) {
		printf("не хватает памяти");
	}
	
	add_lua_arguments(state, arguments, number_of_arguments);
	
	register_lua_api(state);
	
	if(
		luaL_dofile(state, "api.lua")
		|| luaL_dofile(state, "reactive.lua")
		|| luaL_dofile(state, script_path)
	) {
		print("%s\n", lua_tostring(state, -1));
		lua_pop(state, 1);
		goto error;
	}
	
	lua_close(state);
	
	return 0;
	
	error: {
		lua_close(state);
		return 1;
	}
}