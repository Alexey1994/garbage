return function(global, parent, attributes)local outer = {} local self = {__root_children={},
	x = attributes and attributes['x'] or variable(0),
	y = attributes and attributes['y'] or variable(0),
	width = attributes and attributes['width'] or variable(0),
	height = attributes and attributes['height'] or variable(0),
	name = attributes and attributes['name'] or variable(0),
}
DOM_Element(nil, self, parent, ({_id=constant('children'), id=constant('main'), name=self.name, height=self.height, width=self.width, y=self.y, x=self.x}))



self.background = attributes and attributes.background or variable(rgb(255, 255, 255))

self.main.draw.bind(function(element)
	local display = element.window.begin_draw()
	api.draw_rectangle(display, 0, 0, element.width.get() + 1, element.height.get() + 1, self.background.get())
	element.window.end_draw()
end)


outer.show = function()
	self.main.window.show()
end

outer.show_maximized = function()
	self.main.window.show_maximized()
end

outer.show_fullscreen = function()
	self.main.window.show_fullscreen()
end

outer.hide = function()
	self.main.window.hide()
end

outer.close = self.main.close

outer.background = self.background

outer.get_children_place = function()
	return self.children
end
if attributes and attributes.id then global[attributes.id.get()] = outer end
return outer end