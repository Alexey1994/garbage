return function(global, parent, attributes)local outer = {} local self = {__root_children={},
	action3 = attributes and attributes['action3'] or variable(0),
	action4 = attributes and attributes['action4'] or variable(0),
}
DOM_Element('Window', self, parent, {background=variable(1052688), height=variable(200), width=variable(300), y=variable(0), x=variable(0), name=constant('попка'), id=constant('win')})
.block().component('Button', {text=constant('кнопочка'), y=variable(10), x=variable(10)})
.component('Button', {text=constant('жыжка'), y=variable(30), x=variable(10)})
.component('Button', {click=self.action3, text=constant('сиська'), y=variable(50), x=variable(10)})
.end_block()DOM_Element('Window', self, parent, {background=variable(1052688), height=variable(200), width=variable(300), y=variable(0), x=variable(300), name=constant('платочек'), id=constant('win2')})
.block().component('Button', {text=constant('кнопочка'), y=variable(10), x=variable(10)})
.component('Button', {text=constant('жыжка'), y=variable(30), x=variable(10)})
.component('Button', {text=constant('сиська'), y=variable(50), x=variable(10)})
.component('Button', {click=self.action4, text=constant('боярышник'), y=variable(70), x=variable(10)})
.end_block()


self.action3.bind(function()
	print('action3')
end)

self.action4.bind(function()
	print('action4')
end)

self.win.show_maximized()
self.win2.show()

while not self.win.close.get() do
	while api.pop_window_message() ~= 0 do
	end

	Process.sleep(20)
end
if attributes and attributes.id then global[attributes.id.get()] = outer end
return outer end