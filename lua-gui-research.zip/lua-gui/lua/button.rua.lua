return function(global, parent, attributes)local outer = {} local self = {__root_children={},
	x = attributes and attributes['x'] or variable(0),
	y = attributes and attributes['y'] or variable(0),
	mousedown = attributes and attributes['mousedown'] or variable(0),
	mouseup = attributes and attributes['mouseup'] or variable(0),
	mousemove = attributes and attributes['mousemove'] or variable(0),
	mousehover = attributes and attributes['mousehover'] or variable(0),
	mouseleave = attributes and attributes['mouseleave'] or variable(0),
}
DOM_Element(nil, self, parent, ({mouseleave=self.mouseleave, mousehover=self.mousehover, mousemove=self.mousemove, mouseup=self.mouseup, mousedown=self.mousedown, height=variable(20), width=variable(180), y=self.y, x=self.x, id=constant('button_background')}))



self.click = attributes and attributes.click or variable()
self.text = attributes and attributes.text or variable('Button')

local state = 'normal'

self.mousedown.bind(function()
	state = 'pressed'
	self.button_background.window.redraw()
end)

self.mouseup.bind(function()
	if state == 'pressed' then
		self.click.set(1)
	end
	
	state = 'hover'
	self.button_background.window.redraw()
end)

self.mousehover.bind(function()
	if state == 'hover' then
		return
	end
	
	state = 'hover'
	self.button_background.window.redraw()
end)

self.mouseleave.bind(function()
	state = 'normal'
	self.button_background.window.redraw()
end)

self.button_background.draw.bind(function(element)
	local display = element.window.begin_draw()
		
	if state == 'normal' then
		api.draw_rectangle(display, 0, 0, element.width.get(), element.height.get(), rgb(128, 128, 128))
		local text_width, text_height = api.calculate_text_size(display, self.text.get())
		api.draw_text(display, self.text.get(), (element.width.get() - text_width) / 2, (element.height.get() - text_height) / 2 - 1, rgb(255, 255, 255))
	elseif state == 'pressed' then
		api.draw_rectangle(display, 0, 0, element.width.get(), element.height.get(), rgb(64, 64, 64))
		local text_width, text_height = api.calculate_text_size(display, self.text.get())
		api.draw_text(display, self.text.get(), (element.width.get() - text_width) / 2 + 1, (element.height.get() - text_height) / 2, rgb(255, 255, 255))
	elseif state == 'hover' then
		api.draw_rectangle(display, 0, 0, element.width.get(), element.height.get(), rgb(196, 196, 196))
		local text_width, text_height = api.calculate_text_size(display, self.text.get())
		api.draw_text(display, self.text.get(), (element.width.get() - text_width) / 2, (element.height.get() - text_height) / 2 - 1, rgb(255, 255, 255))
	end
		
	element.window.end_draw()
end)


outer.click = self.click
outer.text = self.text
if attributes and attributes.id then global[attributes.id.get()] = outer end
return outer end