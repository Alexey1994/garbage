function print(...)
	local is_first = true
	local printed_tables = {}
	
	function print_value(value, level)
		if type(value) == 'number' then
			api.print_number(value)
		elseif type(value) == 'string' then
			api.print_string(value)
		elseif type(value) == 'table' then
			if not printed_tables[value] then
				printed_tables[value] = true
				
				local is_first = true
				local new_line = true --length(value) > 2
				api.print_string('{')
				for i, v in pairs(value) do
					if not is_first then
						api.print_string(',')
					end
					
					if new_line then
						api.print_string('\n')

						for i = 1, level do
							api.print_string('  ')
						end
					end
					
					if type(i) == 'table' then
						api.print_string('table')
					else
						print_value(i, level + 1)
					end
					
					api.print_string(' = ')
					print_value(v, level + 1)

					is_first = false
				end
				
				if new_line then
					api.print_string('\n')
					
					for i = 1, level - 1 do
						api.print_string('  ')
					end
				end
				
				api.print_string('}')
			else
				api.print_string('{cycled}')
			end
		else
			api.print_string(type(value))
		end
	end
	
	local arg = {...}

	for i = 1, #arg do
		if not is_first then
			api.print_string(', ')
		end
		
		print_value(arg[i], 1)
		
		is_first = false
	end
	
	api.print_string('\n')
end


Process = {
	execute = function(command)
		local process = api.create_process(command)
		
		if not process then
			return nil
		end
		
		api.wait_process(process)
		local exit_code = api.get_process_exit_code(process)
		api.destroy_process(process)
		return exit_code
	end,
	
	sleep = function(milliseconds)
		api.sleep(milliseconds)
	end
}

execute = Process.execute

File = {
	open = function(name)
		local file = api.open_file(name)
	
		if not file then
			return nil
		end
		
		return {
			close = function()
				api.close_file(file)
			end,
			
			get_time = function()
				return api.get_file_time(file)
			end,
			
			set_time = function(time)
				api.set_file_time(file, time)
			end
		}
	end,
	
	create = function(name)
	end,
	
	rename = function(name)
	end,
	
	delete = function(name)
	end,
	
	find = function(path)
		return api.find_files(path)
	end
}

Window = {
	CREATE = 1,
	DESTROY = 2,
	MOVE = 3, --перемещение
	SIZE = 5, --изменение размера
	ACTIVATE = 6, --срабатывает при появлении, фокусе главного окна
	SETFOCUS = 7,
	KILLFOCUS = 8,
	SETTEXT = 12,
	GETTEXT = 13,
	DRAW = 15,
	CLOSE = 16,
	ERASEBKGND = 20,
	SHOWWINDOW = 24,
	ACTIVATEAPP = 28,
	SET_CURSOR = 32, --курсор наведён на элемент либо нажатие по элементу
	MOUSEACTIVATE = 33, --нажатие мышью по элементу включая всех родителей
	CHILDACTIVATE = 34,
	GETMINMAXINFO = 36,
	WINDOWPOSCHANGING = 70,
	WINDOWPOSCHANGED = 71,
	GET_ICON = 127,
	NCCALCSIZE = 131,
	NCHITTEST = 132,
	NCPAINT = 133,
	NCACTIVATE = 134,
	GETDLGCODE = 135,
	NCMOUSEMOVE = 160,
	
	KEY_DOWN = 256,
	KEY_UP = 257,
	
	COMMAND = 273,
	CTLCOLORBTN = 309,
	
	MOUSE_MOVE = 512,
	MOUSE_DOWN = 513,
	MOUSE_UP = 514,
	
	PARENTNOTIFY = 528, --нажатие мышью по дочернему элементу
	SIZING = 532,
	CAPTURECHANGED = 533,
	MOVING = 534,
	
	ENTERSIZEMOVE = 561,
	EXITSIZEMOVE = 562,
	
	IME_SETCONTEXT = 641,
	IME_NOTIFY = 642,
	
	MOUSEHOVER = 673,
	MOUSELEAVE = 675,

	
	pop_message = function()
		return api.pop_window_message()
	end,
	
	create = function(handler, parent)
		--local window
		
		--if parent then
		--	window = api.create_subwindow(handler, parent)
		--else
		--	window = api.create_window(handler)
		--end
		
		local parent_window
		if parent then
			parent_window = parent._get_window()
		end

		local window = api.create_window(parent_window, handler)
	
		return {
			_get_window = function()
				return window
			end,
			
			create_subwindow = function(handler)
				return Window.create(handler, window)
			end,
			
			set_name = function(name)
				api.set_window_name(window, name)
			end,
			
			set_position = function(x, y, width, height)
				api.set_window_position(window, x, y, width, height)
			end,
			
			get_position = function()
				return api.get_window_position(window)
			end,

			get_client_position = function()
				return api.get_window_client_position(window)
			end,
			
			show = function()
				api.show_window(window)
			end,
			
			show_maximized = function()
				api.show_maximized_window(window)
			end,
			
			show_fullscreen = function()
				api.show_fullscreen_window(window)
			end,
			
			hide = function()
				api.hide_window(window)
			end,
			
			redraw = function()
				api.redraw_window(window)
			end,
			
			--next_message = function()
			--	return api.get_next_window_message(%window)
			--end,
			
			get_display = function()
				return api.get_window_display(window)
			end,

			destroy = function()
				api.destroy_window(window)
			end,
			
			begin_draw = function()
				return api.begin_window_draw(window)
			end,
			
			end_draw = function()
				api.end_window_draw(window)
			end,
			
			create_display3D = function()
				local display = api.get_window_display(window)
				local display3D = api.create_display3D(display)
		
				return {
					begin_draw = function()
						api.begin_draw_3D(display, display3D)
					end,
					
					clear  = function()
						api.gl_clear()
					end,
					
					begin_triangles = function()
						api.gl_begin_triangles()
					end,
					
					color = function(r, g, b)
						api.gl_color(r, g, b)
					end,
					
					vertex = function(x, y, z)
						api.gl_vertex(x, y, z)
					end,
					
					normal = function(x, y, z)
						api.gl_normal(x, y, z)
					end,
					
					end_triangles = function()
						api.gl_end()
					end,
					
					load_identity = function(x, y, z)
						api.gl_load_identity()
					end,
					
					translate = function(x, y, z)
						api.gl_translate(x, y, z)
					end,
					
					rotate = function(angle, x, y, z)
						api.gl_rotate(angle, x, y, z)
					end,
					
					scale = function(x, y, z)
						api.gl_scale(x, y, z)
					end,
					
					end_draw = function()
						api.end_draw_3D(display)
					end,
					
					destroy = function()
						api.destroy_display3D(display3D)
					end
				}
			end
		}
	end
}

Button = {
	create = function(parent)
		local window = api.create_button(parent)

		return {
			get_window = function()
				return window
			end,
			
			create_subwindow = function()
				return Window.create(window)
			end,
			
			set_name = function(name)
				api.set_window_name(window, name)
			end,
			
			set_position = function(x, y, width, height)
				api.set_window_position(window, x, y, width, height)
			end,
			
			show = function()
				api.show_window(window)
			end,
			
			hide = function()
				api.hide_window(window)
			end,
			
			next_message = function()
				return api.get_next_window_message(window)
			end,

			destroy = function()
				api.destroy_window(window)
			end
		}
	end
}

Display = {
	get_main = function(index)
		return api.get_main_display(index)
	end,
	
	create = function(display, width, height)
	end,

	create3D = function(display)
		local display3D = api.create_display3D(display)
		
		return {
			begin_draw = function()
				api.begin_draw_3D(display, display3D)
			end,
			
			end_draw = function()
				api.end_draw_3D(display)
			end,
			
			destroy = function()
				api.destroy_display3D(display3D)
			end
		}
	end
}

function rgb(r, g, b)
	return r + (g * 256) + (b * 256 * 256)
end