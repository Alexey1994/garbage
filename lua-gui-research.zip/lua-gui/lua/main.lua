add_component('Window', require('window.rua.lua'))
add_component('Button', require('button.rua.lua'))
Compose = require('compose.rua.lua')

Compose({}, nil, {})