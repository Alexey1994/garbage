function constant(initial_value)
	return {
		set = function(new_value)
			return initial_value
		end,
		
		get = function()
			return initial_value
		end,
		
		bind = function(change_detector)
		end,
		
		unbind = function()
		end,
	}
end

function variable(initial_value)
	local current_value = {initial_value}
	local change_detectors = {}

	return {
		set = function(new_value)
			local old_value = current_value[1]
		
			for i = 1, #change_detectors do
				local change_detector = change_detectors[i]
				change_detector(new_value, old_value)
			end
			
			current_value[1] = new_value
			
			return old_value
		end,
		
		get = function()
			return current_value[1]
		end,
		
		bind = function(change_detector)
			change_detectors[#change_detectors + 1] = change_detector
		end,
		
		unbind = function(change_detector)
			local change_detector_index
			
			for i = 1, #change_detectors do
				local v = change_detectors[i]

				if v == change_detector then
					change_detector_index = i
					break
				end
			end
			
			if change_detector_index then
				change_detectors[change_detector_index] = nil
				
				for i = change_detector_index, #change_detectors do
					change_detectors[i] = change_detectors[i + 1]
				end
			end
		end,
	}
end

function add(value2, value1)
	local v1 = value1.get()
	local v2 = value2.get()
	local result
	
	if v1 and v2 then
		result = variable(v1 + v2)
	else
		result = variable()
	end
	
	value1.bind(function(changed_value)
		result.set(value1.get() + value2.get())
	end)
	
	value2.bind(function(changed_value)
		result.set(value1.get() + value2.get())
	end)
	
	return result
end

function mul(value2, value1)
	local v1 = value1.get()
	local v2 = value2.get()
	local result
	
	if v1 and v2 then
		result = variable(v1 * v2)
	else
		result = variable()
	end
	
	value1.bind(function(changed_value)
		result.set(value1.get() * value2.get())
	end)
	
	value2.bind(function(changed_value)
		result.set(value1.get() * value2.get())
	end)
	
	return result
end

function lesser(value2, value1)
	local v1 = value1.get()
	local v2 = value2.get()
	local result
	
	if v1 and v2 then
		result = variable(v1 < v2)
	else
		result = variable()
	end
	
	value1.bind(function(changed_value)
		result.set(value1.get() < value2.get())
	end)
	
	value2.bind(function(changed_value)
		result.set(value1.get() < value2.get())
	end)
	
	return result
end

function filter(alternative_value, value, condition)
	local c = condition.get()
	local v = value.get()
	local result
	
	if c then
		if v then
			result = variable(v)
		else
			result = variable()
		end
	else
		if alternative_value then
			result = variable(alternative_value.get())
		else
			result = variable()
		end
	end
	
	condition.bind(function(changed_value)
		if changed_value then
			result.set(value.get())
		elseif alternative_value then
			result.set(alternative_value.get())
		end
	end)
	
	return result
end


function printer(value)
	local current_value = value.get()
	if current_value then
		print(current_value)
	end
	
	local change_detector = function(changed_value)
		print(changed_value)
	end
	
	value.bind(change_detector)
	--value.unbind(change_detector)
	
	return {
		unbind = function()
			value.unbind(change_detector)
		end
	}
end


function window(options, parent)
	local context = {
		x = options.x or variable(0),
		y = options.y or variable(0),
		width = options.width or variable(100),
		height = options.height or variable(100),
		name = options.name or variable(''),

		draw = options.draw or variable(),
		close = options.close or variable(),
		mousedown = options.mousedown or variable(),
		mouseup = options.mouseup or variable(),
		mousemove = options.mousemove or variable(),
		mousehover = options.mousehover or variable(),
		mouseleave = options.mouseleave or variable(),
		click = options.click or variable(),
		keydown = options.keydown or variable(),
		keyup = options.keyup or variable(),
		command = options.command or variable(),
		erasebackground = options.erasebackground or variable(),
	}

	function change_position()
		context.window.set_position(
			context.x.get(),
			context.y.get(),
			context.width.get(),
			context.height.get()
		)
	end

	context.x.bind(function(new_value, old_value)
		if new_value ~= old_value  then
			change_position()
		end
	end)
	
	context.y.bind(function(new_value, old_value)
		if new_value ~= old_value  then
			change_position()
		end
	end)
	
	context.width.bind(function(new_value, old_value)
		if new_value ~= old_value  then
			change_position()
		end
	end)

	context.height.bind(function(new_value, old_value)
		if new_value ~= old_value  then
			change_position()
		end
	end)

	context.name.bind(function(new_value, old_value)
		if new_value ~= old_value  then
			context.window.set_name(new_value)
		end
	end)
	
	context.window = Window.create(
		function(type, p1, p2, p3)
			--print(type, ' ', p1, ' ', p2)
			
			if type == Window.CREATE then

			elseif type == Window.DRAW then
				context.draw.set(context)
				--context.draw.set(1)
			elseif type == Window.CLOSE then
				context.close.set(1)
			elseif type == Window.MOUSE_DOWN then
				context.mousedown.set(1)
			elseif type == Window.MOUSE_UP then
				context.mouseup.set(1)	
			elseif type == Window.MOUSE_MOVE then
				context.mousemove.set(p2)--{p2, p3})
			elseif type == Window.KEY_DOWN then
				context.keydown.set(p1)
			elseif type == Window.KEY_UP then
				context.keyup.set(p1)
			elseif type == Window.COMMAND then
				context.command.set(p1)
			
			elseif type == Window.SHOWWINDOW then
			elseif type == Window.ACTIVATEAPP then
			elseif type == Window.NCACTIVATE then
			elseif type == Window.WINDOWPOSCHANGED then
			elseif type == Window.WINDOWPOSCHANGING then
			elseif type == Window.MOVING then
			
			elseif type == Window.MOVE then
				if parent then
					return
				end
				
				local x, y, width, height = context.window.get_position()
				context.x.set(x)
				context.y.set(y)
			elseif type == Window.SIZE then
				if parent then
					return
				end

				local x, y, width, height = context.window.get_position()
				context.width.set(width)
				context.height.set(height)
			elseif type == Window.SIZING then
				--print('SIZING', p2, p3)
			elseif type == Window.CAPTURECHANGED then
			
			elseif type == Window.ENTERSIZEMOVE then
				
			elseif type == Window.EXITSIZEMOVE then
				
			elseif type == Window.GETTEXT then
			
			elseif type == Window.SETTEXT then
				
			elseif type == Window.GETMINMAXINFO then
			
			elseif type == Window.ERASEBKGND then
				context.erasebackground.set(1)
			elseif type == Window.NCCALCSIZE then
				
			elseif type == Window.ACTIVATE then
				--print('ACTIVATE', p2, p3)
			
			elseif type == Window.SETFOCUS then
				--print('SETFOCUS', p2, p3)
			elseif type == Window.KILLFOCUS then
				
			elseif type == Window.MOUSEACTIVATE then
				--print('MOUSEACTIVATE', p2, p3)
			elseif type == Window.CHILDACTIVATE then
				print('CHILDACTIVATE', p2, p3)
			elseif type == Window.PARENTNOTIFY then
				--print('PARENTNOTIFY', p1, p2, p3)
				
			
			elseif type == Window.GET_ICON then
			elseif type == Window.SET_CURSOR then
				--print('SET_CURSOR', p1, p2, p3)
			elseif type == Window.NCHITTEST then
			
			elseif type == Window.MOUSEHOVER then
				--print('MOUSEHOVER', p1, p2, p3)
				context.mousehover.set(1)
			
			elseif type == Window.MOUSELEAVE then
				--print('MOUSELEAVE', p1, p2, p3)
				context.mouseleave.set(1)
				
				
			elseif type == Window.NCMOUSEMOVE then
			elseif type == Window.GETDLGCODE then
			elseif type == Window.CTLCOLORBTN then
			elseif type == Window.NCPAINT then
			elseif type == Window.IME_SETCONTEXT then
			elseif type == Window.IME_NOTIFY then
			else
				--print(type, p1, p2, p3)
			end
		end,
		parent
	)
	
	context.display = context.window.get_display()
	
	change_position()
	context.window.set_name(context.name.get())

	return context
end

function button(parent_window, options)
	local button_window = Button.create(parent_window)
	
	local pos = {
		x = 0,
		y = 0,
		width = 50,
		height = 20
	}
	
	local options_values = {
		text = ''
	}
	
	if options.x then
		pos.x = options.x.get()
			
		options.x.bind(function(changed_value)
			pos.x = changed_value
			button_window.set_position(pos.x, pos.y, pos.width, pos.height)
		end)
	end
		
	if options.y then
		pos.y = options.y.get()
		
		options.y.bind(function(changed_value)
			pos.y = changed_value
			button_window.set_position(pos.x, pos.y, pos.width, pos.height)
		end)
	end
		
	if options.width then
		pos.width = options.width.get()
			
		options.width.bind(function(changed_value)
			pos.width = changed_value
			button_window.set_position(pos.x, pos.y, pos.width, pos.height)
		end)
	end
	
	if options.height then
		pos.height = options.height.get()
			
		options.height.bind(function(changed_value)
			pos.height = changed_value
			button_window.set_position(pos.x, pos.y, pos.width, pos.height)
		end)
	end
		
	button_window.set_position(pos.x, pos.y, pos.width, pos.height)
		
	if options.text then
		options_values.text = options.text.get()
		button_window.set_name(options_values.text)

		options.text.bind(function(changed_value)
			options_values.text = '' .. changed_value
			button_window.set_name(options_values.text)
		end)
	end
	
	button_window.click = variable()
	
	return button_window
end


components = {}

function add_component(name, component)
	if components[name] then
		return
	end
	
	components[name] = component
end

function DOM_Element(name, global, parent, attributes)
	local self = {
		children = {},
		parent = parent
	}

	if parent then
		if name then
			self.window_element = components[name](global, parent.window_element.get_children_place(), attributes)
		else
			self.window_element = window(attributes, parent.window_element.window)
		end
		
		parent.children[#(parent.children) + 1] = self
	else
		if name then
			self.window_element = components[name](global, nil, attributes)
		else
			self.window_element = window(attributes)
		end

		global.__root_children[#(global.__root_children) + 1] = self
	end
	
	if attributes and attributes.id then
		global[attributes.id.get()] = self.window_element
	end
	
	if attributes and attributes._id then
		global[attributes._id.get()] = self
	end

	self.block = function()
		if parent then
			return self.children[#(self.children)]
		else
			return global.__root_children[#(global.__root_children)]
		end
	end
	
	self.end_block = function()
		return parent
	end
	
	self.window = function(attributes)
		local element = DOM_Element(nil, global, self, attributes)
		return self
	end
	
	self.component = function(name, attributes)
		local element = DOM_Element(name, global, self, attributes)
		return self
	end

	return self
end