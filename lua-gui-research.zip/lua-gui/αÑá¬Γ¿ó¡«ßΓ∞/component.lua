function constant(initial_value)
	return {
		set = function(new_value)
			return %initial_value
		end,
		
		get = function()
			return %initial_value
		end,
		
		bind = function(change_detector)
		end,
		
		unbind = function()
		end,
	}
end

function variable(initial_value)
	local current_value = {initial_value}
	local change_detectors = {}

	return {
		set = function(new_value)
			%current_value[1] = new_value
			
			for i, v in %change_detectors do
				v.set(%current_value[1])
			end
			
			return %current_value[1]
		end,
		
		get = function()
			return %current_value[1]
		end,
		
		bind = function(change_detector)
			%change_detectors[length(%change_detectors) + 1] = change_detector
		end,
		
		unbind = function(change_detector)
			local change_detector_index
			
			for i, v in %change_detectors do
				if v == change_detector then
					change_detector_index = i
					break
				end
			end
			
			if change_detector_index then
				%change_detectors[change_detector_index] = nil
				
				for i = change_detector_index, length(%change_detectors) do
					%change_detectors[i] = %change_detectors[i + 1]
				end
			end
		end,
	}
end

function add(value2, value1)
	local v1 = value1.get()
	local v2 = value2.get()
	local result
	
	if v1 and v2 then
		result = variable(v1 + v2)
	else
		result = variable()
	end
	
	value1.bind({
		set = function(changed_value)
			%result.set(%value1.get() + %value2.get())
		end
	})
	
	value2.bind({
		set = function(changed_value)
			%result.set(%value1.get() + %value2.get())
		end
	})
	
	return result
end

function mul(value2, value1)
	local v1 = value1.get()
	local v2 = value2.get()
	local result
	
	if v1 and v2 then
		result = variable(v1 * v2)
	else
		result = variable()
	end
	
	value1.bind({
		set = function(changed_value)
			%result.set(%value1.get() * %value2.get())
		end
	})
	
	value2.bind({
		set = function(changed_value)
			%result.set(%value1.get() * %value2.get())
		end
	})
	
	return result
end

function lesser(value2, value1)
	local v1 = value1.get()
	local v2 = value2.get()
	local result
	
	if v1 and v2 then
		result = variable(v1 < v2)
	else
		result = variable()
	end
	
	value1.bind({
		set = function(changed_value)
			%result.set(%value1.get() < %value2.get())
		end
	})
	
	value2.bind({
		set = function(changed_value)
			%result.set(%value1.get() < %value2.get())
		end
	})
	
	return result
end

function filter(alternative_value, value, condition)
	local c = condition.get()
	local v = value.get()
	local result
	
	if c then
		if v then
			result = variable(v)
		else
			result = variable()
		end
	else
		if alternative_value then
			result = variable(alternative_value.get())
		else
			result = variable()
		end
	end
	
	condition.bind({
		set = function(changed_value)
			if changed_value then
				%result.set(%value.get())
			elseif %alternative_value then
				%result.set(%alternative_value.get())
			end
		end
	})
	
	return result
end


function printer(value)
	local current_value = value.get()
	if current_value then
		print(current_value)
	end
	
	local change_detector = {
		set = function(changed_value)
			print(changed_value)
		end
	}
	
	value.bind(change_detector)
	--value.unbind(change_detector)
	
	return {
		unbind = function()
			%value.unbind(%change_detector)
		end
	}
end


function window(options, parent)
	local context = {
		draw = variable(),
		close = variable(),
		mousedown = variable(),
		mouseup = variable(),
		mousemove = variable(),
		click = variable(),
		keydown = variable(),
		keyup = variable(),
		command = variable(),
		erasebackground = variable(),
	}
	
	local default = {
		change_window_pos = true,
		change_window_name = true,
		
		--x = 0,
		--y = 0,
		--width = 100,
		--height = 100,
		--name = ''
	}
	
	--local options_values = {
	--	name = ''
	--}
	
	local current_window = Window.create(
		function(type, p1, p2, p3)
			--print(type, ' ', p1, ' ', p2)
			
			if type == Window.DRAW then
				%context.draw.set(%context)
			elseif type == Window.CLOSE then
				%context.close.set(1)
			elseif type == Window.MOUSE_DOWN then
				%context.mousedown.set(1)
			elseif type == Window.MOUSE_UP then
				%context.mouseup.set(1)	
			elseif type == Window.MOUSE_MOVE then
				%context.mousemove.set(p2)--{p2, p3})
			elseif type == Window.KEY_DOWN then
				%context.keydown.set(p1)
			elseif type == Window.KEY_UP then
				%context.keyup.set(p1)
			elseif type == Window.COMMAND then
				%context.command.set(p1)
			elseif type == Window.WINDOWPOSCHANGED then
			
			elseif type == Window.WINDOWPOSCHANGING then
			
			elseif type == Window.SIZE then
				if %context.width then
					%default.change_window_pos = false
					%context.width.set(p2)
				end

				if %context.height then
					%default.change_window_pos = false
					%context.height.set(p3)
				end
			elseif type == Window.SIZING then
				
			elseif type == Window.CAPTURECHANGED then
			
			elseif type == Window.ENTERSIZEMOVE then
				
			elseif type == Window.EXITSIZEMOVE then
				
			elseif type == Window.GETTEXT then
			
			elseif type == Window.GETMINMAXINFO then
			
			elseif type == Window.ERASEBKGND then
				%context.erasebackground.set(1)
			elseif type == Window.NCCALCSIZE then
				
			
			
			elseif type == Window.GET_ICON then
			elseif type == Window.SET_CURSOR then
			elseif type == Window.NCHITTEST then
			elseif type == Window.NCMOUSEMOVE then
			elseif type == Window.GETDLGCODE then
			elseif type == Window.CTLCOLORBTN then
			elseif type == Window.NCPAINT then
			else
				print(type, ' ', p1, ' ', p2)
			end
		end,
		parent
	)
	
	function change_position()
		if not %default.change_window_pos then
			%default.change_window_pos = true
			return
		end
		
		print(
			%context.x.get(), ', ',
			%context.y.get(), ', ',
			%context.width.get(), ', ',
			%context.height.get()
		)
		
		%current_window.set_position(
			%context.x.get(),
			%context.y.get(),
			%context.width.get(),
			%context.height.get()
		)
	end

	
	if options.x then
		context.x = options.x
	else
		context.x = variable(0)
	end
	
	context.x.bind({
		set = function(changed_value)
			change_position()
		end
	})
	
	
	if options.y then
		context.y = options.y
	else
		context.y = variable(0)
	end
	
	context.y.bind({
		set = function(changed_value)
			change_position()
		end
	})
	
	
	if options.width then
		context.width = options.width
	else
		context.width = variable(100)
	end
	
	context.width.bind({
		set = function(changed_value)
			change_position()
		end
	})
	
	
	if options.height then
		context.height = options.height
	else
		context.height = variable(100)
	end
	
	context.height.bind({
		set = function(changed_value)
			change_position()
		end
	})
	
	change_position()
	
	
	if options.name then
		context.name = options.name
	else
		context.name = variable('')
	end
	
	context.name.bind({
		set = function(changed_value)
			if not %default.change_window_name then
				%default.change_window_name = true
				return
			end
			
			%current_window.set_name(changed_value)
		end
	})
	
	current_window.set_name(context.name.get())

	
	context.window = current_window
	context.display = current_window.get_display()
	
	--if options.name then
	--	options_values.name = options.name.get()
	--	current_window.set_name(options_values.name)

	--	options.name.bind({
	--		set = function(changed_value)
	--			%options_values.name = '' .. changed_value
	--			%current_window.set_name(%options_values.name)
	--		end
	--	})
	--end

	return context
end

function button(parent_window, options)
	local button_window = Button.create(parent_window)
	
	local pos = {
		x = 0,
		y = 0,
		width = 50,
		height = 20
	}
	
	local options_values = {
		text = ''
	}
	
	if options.x then
		pos.x = options.x.get()
			
		options.x.bind({
			set = function(changed_value)
				%pos.x = changed_value
				%button_window.set_position(%pos.x, %pos.y, %pos.width, %pos.height)
			end
		})
	end
		
	if options.y then
		pos.y = options.y.get()
		
		options.y.bind({
			set = function(changed_value)
				%pos.y = changed_value
				%button_window.set_position(%pos.x, %pos.y, %pos.width, %pos.height)
			end
		})
	end
		
	if options.width then
		pos.width = options.width.get()
			
		options.width.bind({
			set = function(changed_value)
				%pos.width = changed_value
				%button_window.set_position(%pos.x, %pos.y, %pos.width, %pos.height)
			end
		})
	end
	
	if options.height then
		pos.height = options.height.get()
			
		options.height.bind({
			set = function(changed_value)
				%pos.height = changed_value
				%button_window.set_position(%pos.x, %pos.y, %pos.width, %pos.height)
			end
		})
	end
		
	button_window.set_position(pos.x, pos.y, pos.width, pos.height)
		
	if options.text then
		options_values.text = options.text.get()
		button_window.set_name(options_values.text)

		options.text.bind({
			set = function(changed_value)
				%options_values.text = '' .. changed_value
				%button_window.set_name(%options_values.text)
			end
		})
	end
	
	button_window.click = variable()
	
	return button_window
end


-------------------------------------------------------------------------------

function rgb(r, g, b)
	return r + (g * 256) + (b * 256 * 256)
end


function Component(options)
	return function(structure)
		local options_values = {
			name = %options.name or 'Anonim',
			create = %options.create or function() end,
			init = %options.init or function() end,
			structure = %options.structure
		}
		
		local self = {
			name = options_values.name,
			structure = structure or options_values.structure,

			create = options_values.create,
			
			create_children = function(self)
				if type(%structure) == 'table' then
					for i = 1, length(%structure) do
						%structure[i]:create(self)
					end
				end
			end
		}

		return self
	end
end


Button2 = Component{
	name = 'Button',

	create = function(self, parent)
		--self.window_children = parent.window_children
		--self.window = parent.window

		self.element = button(
			parent.element.window._get_window(), {
				x = self.structure.x,
				y = self.structure.y,
				width = self.structure.width,
				height = self.structure.height,
				text = self.structure.text
			}
		)
		
		self.click = self.element.click

		if self.structure and self.structure.click then
			self.click.bind({
				set = function(value)
					%self.structure.click(value)
				end
			})
		end

		--parent.window_children[length(self.window_children) + 1] = self.element
	end
}

Window2 = Component{
	name = 'Window',
	
	create = function(self, parent)
		--local parent_element = nil
		
		if parent then
			self.element = window({
				x = self.structure.x,
				y = self.structure.y,
				width = self.structure.width,
				height = self.structure.height,
				name = self.structure.title
			}, parent.element.window)
		else
			self.element = window({
				x = self.structure.x,
				y = self.structure.y,
				width = self.structure.width,
				height = self.structure.height,
				name = self.structure.title
			})
		end
		
		self.x = self.element.x
		self.y = self.element.y
		self.width = self.element.width
		self.height = self.element.height
		self.title = self.element.name
		
		--self.backgroundcolor = variable(255 + (255 * 256) + (255 * 256 * 256))
		
		--self.draw_background = function(color)
		--	print(%self.width.get(), ' ', %self.height.get())
		--	local display = %self.element.window.begin_draw()
		--	api.draw_rectangle(display, 0, 0, %self.width.get() + 1, %self.height.get() + 1, color)
		--	%self.element.window.end_draw()
		--end
		
		--self.backgroundcolor.bind({
		--	set = function(new_value)
		--		%self.draw_background(new_value)
		--	end
		--})
		
		--self.element.erasebackground.bind({
		--	set = function()
				--print('erase')
		--		%self.draw_background(%self.backgroundcolor.get())
		--	end
		--})

		self.draw = self.element.draw
		self.close = self.element.close
		self.click = self.element.click
		self.mousedown = self.element.mousedown
		self.mouseup = self.element.mouseup
		self.mousemove = self.element.mousemove
		self.keydown = self.element.keydown
		self.keyup = self.element.keyup
		self.command = self.element.command
		
		if self.structure and self.structure.draw then
			self.draw.bind({
				set = function(value)
					--%self.draw_background(%self.backgroundcolor.get())
					%self.structure.draw(%self, value)
				end
			})
		end
		
		if self.structure and self.structure.mousedown then
			self.mousedown.bind({
				set = function(value)
					%self.structure.mousedown(%self, value)
				end
			})
		end

		if self.structure and self.structure.mouseup then
			self.mouseup.bind({
				set = function(value)
					%self.structure.mouseup(%self, value)
				end
			})
		end
		
		if self.structure and self.structure.mousemove then
			self.mousemove.bind({
				set = function(value)
					%self.structure.mousemove(%self, value)
				end
			})
		end
		
		if self.structure and self.structure.keydown then
			self.keydown.bind({
				set = function(value)
					%self.structure.keydown(%self, value)
				end
			})
		end
		
		if self.structure and self.structure.keyup then
			self.keyup.bind({
				set = function(value)
					%self.structure.keyup(%self, value)
				end
			})
		end
		
		if self.structure and self.structure.command then
			self.command.bind({
				set = function(value)
					%self.structure.command(%self, value)
				end
			})
		end
		
		self.window = self.element
		self.window_children = {}
		
		self:create_children()
	end,
	
	init = function(self)

	end
}


w = Window2{
	x = variable(100),
	y = variable(100),
	width = variable(400),
	height = variable(400),
	title = variable('Window'),
	
	draw = function(self, window)
		local display = self.element.window.begin_draw()
		api.draw_rectangle(display, 0, 0, self.width.get() + 1, self.height.get() + 1, rgb(255, 255, 255))
		api.draw_text(display, 'соска', 10, 120, 255);
		self.element.window.end_draw()
	end,

	click = function()
		print('Window2')
	end,
	
	keydown = function(self, keycode)
		--print(keycode)
	end;

	Window2{
		x = constant(10),
		y = constant(10),
		width = constant(100),
		height = constant(100),
		title = constant('Window'),
		
		draw = function(self)
			local display = self.element.window.begin_draw()
			--api.draw_rectangle(display, 0, 0, 100, 100, 255 + (255 * 256 * 256))
			api.draw_rectangle(display, 0, 0, self.width.get() + 1, self.height.get() + 1, rgb(0, 255, 255))
			api.draw_text(display, 'засоска', 0, 0, 0);
			self.element.window.end_draw()
		end,
		
		mousedown = function()
			print('down')
		end;
		
		Button2{
			x = constant(0),
			y = constant(20),
			width = constant(50),
			height = constant(20),
			text = constant'жыжка',
		},
		
		Button2{
			x = constant(50),
			y = constant(20),
			width = constant(50),
			height = constant(20),
			text = constant'бипка',
		}
	},
	
	Window2{
		x = constant(120),
		y = constant(10),
		width = constant(100),
		height = constant(100),
		title = constant('Window'),
		
		draw = function(self)
			local display = self.element.window.begin_draw()
			--api.draw_rectangle(display, 0, 0, 100, 100, 255 + (255 * 256 * 256))
			api.draw_rectangle(display, 0, 0, self.width.get() + 1, self.height.get() + 1, rgb(0, 0, 255))
			--api.draw_text(display, 'засоска', 0, 0, 0);
			api.draw_text(display, 'jyja', 0, 0, 0);
			self.element.window.end_draw()
		end,
		
		mousedown = function()
			print('down2')
		end,
		
		mousemove = function(self, event)
			--print(event)
		end;
		
		Button2{
			x = constant(0),
			y = constant(20),
			width = constant(50),
			height = constant(20),
			text = constant'жыжка',
		},
		
		Button2{
			x = constant(50),
			y = constant(20),
			width = constant(50),
			height = constant(20),
			text = constant'бипка',
		}
	}
}

--printer(w.down)
--printer(w.up)

--w:show()

w:create()
w.element.window.show()



--w = window({	})
--w.window.show()


while not w.close.get() do
	local message = Window.pop_message()
					
	if message == 0 then
		Process.sleep(20)
	end
end