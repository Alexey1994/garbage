--w = api.create_window(function()
--	print('message')
--end)

--api.set_window_name(w, 'dfg')
--api.show_window(w)

--while 1 do
--	api.get_next_window_message(w)
--end

w = Window.create(function()
	print('message')
end)

w.show()

while 1 do
	w.next_message()
end