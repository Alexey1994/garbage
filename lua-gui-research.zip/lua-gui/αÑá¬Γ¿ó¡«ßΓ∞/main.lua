function constant(initial_value)
	return {
		set = function(new_value)
			return %initial_value
		end,
		
		get = function()
			return %initial_value
		end,
		
		bind = function(change_detector)
		end,
		
		unbind = function()
		end,
	}
end

function variable(initial_value)
	local current_value = {initial_value}
	local change_detectors = {}

	return {
		set = function(new_value)
			%current_value[1] = new_value
			
			for i, v in %change_detectors do
				v.set(%current_value[1])
			end
			
			return %current_value[1]
		end,
		
		get = function()
			return %current_value[1]
		end,
		
		bind = function(change_detector)
			%change_detectors[length(%change_detectors) + 1] = change_detector
		end,
		
		unbind = function()
		end,
	}
end

function add(value1, value2)
	local v1 = value1.get()
	local v2 = value2.get()
	local result
	
	if v1 and v2 then
		result = variable(v1 + v2)
	else
		result = variable()
	end
	
	value1.bind({
		set = function(changed_value)
			%result.set(%value1.get() + %value2.get())
		end
	})
	
	value2.bind({
		set = function(changed_value)
			%result.set(%value1.get() + %value2.get())
		end
	})
	
	return result
end

function mul(value1, value2)
	local v1 = value1.get()
	local v2 = value2.get()
	local result
	
	if v1 and v2 then
		result = variable(v1 * v2)
	else
		result = variable()
	end
	
	value1.bind({
		set = function(changed_value)
			%result.set(%value1.get() * %value2.get())
		end
	})
	
	value2.bind({
		set = function(changed_value)
			%result.set(%value1.get() * %value2.get())
		end
	})
	
	return result
end

function lesser(value1, value2)
	local v1 = value1.get()
	local v2 = value2.get()
	local result
	
	if v1 and v2 then
		result = variable(v1 < v2)
	else
		result = variable()
	end
	
	value1.bind({
		set = function(changed_value)
			%result.set(%value1.get() < %value2.get())
		end
	})
	
	value2.bind({
		set = function(changed_value)
			%result.set(%value1.get() < %value2.get())
		end
	})
	
	return result
end

function filter(condition, value, alternative_value)
	local c = condition.get()
	local v = value.get()
	local result
	
	if c then
		if v then
			result = variable(v)
		else
			result = variable()
		end
	else
		if alternative_value then
			result = variable(alternative_value.get())
		else
			result = variable()
		end
	end
	
	condition.bind({
		set = function(changed_value)
			if changed_value then
				%result.set(%value.get())
			elseif %alternative_value then
				%result.set(%alternative_value.get())
			end
		end
	})
	
	return result
end

function printer(value)
	local current_value = value.get()
	if current_value then
		print(current_value)
	end
	
	value.bind({
		set = function(changed_value)
			print(changed_value)
		end
	})
end


current_window = Window.create()
current_window.show()

function window(options)
	local pos = {
		x = 0,
		y = 0,
		width = 300,
		height = 300
	}
	
	local options_values = {
		name = ''
	}
	
	if options.x then
		if options.x then
			pos.x = options.x.get()
			
			options.x.bind({
				set = function(changed_value)
					%pos.x = changed_value
					current_window.set_position(%pos.x, %pos.y, %pos.width, %pos.height)
				end
			})
		end
		
		if options.y then
			pos.y = options.y.get()
			
			options.y.bind({
				set = function(changed_value)
					%pos.y = changed_value
					current_window.set_position(%pos.x, %pos.y, %pos.width, %pos.height)
				end
			})
		end
		
		if options.width then
			pos.width = options.width.get()
			
			options.width.bind({
				set = function(changed_value)
					%pos.width = changed_value
					current_window.set_position(%pos.x, %pos.y, %pos.width, %pos.height)
				end
			})
		end
	
		if options.height then
			pos.height = options.height.get()
			
			options.height.bind({
				set = function(changed_value)
					%pos.height = changed_value
					current_window.set_position(%pos.x, %pos.y, %pos.width, %pos.height)
				end
			})
		end
		
		current_window.set_position(pos.x, pos.y, pos.width, pos.height)
		
		if options.name then
			options_values.name = options.name.get()
			current_window.set_name(options_values.name)
			
			options.name.bind({
				set = function(changed_value)
					%options_values.name = '' .. changed_value
					current_window.set_name(%options_values.name)
				end
			})
		end
	end
end


--local v1 = variable()
--local v2 = variable()
--local v2 = variable(1)

--print(t.get())
--printer(add(v1, constant(6)))

--v1.set(0)

--window(
--	mul(
--		mul(v1, v1),
--		constant(10)
--	)
--)

x = variable(0)

window({
	x = filter(
		lesser(x, constant(100)),
		x,
		constant(150)
	),
		
	y = filter(
		lesser(x, constant(100)),
		x
	),
		
	name = x
})


count = 0

while 1 do
	local message = current_window.next_message()
	
	if message == 0 then
		x.set(count)
		count = count + 1
		
		Process.sleep(20)
	elseif message == Window.DESTROY then
		break
	end
end