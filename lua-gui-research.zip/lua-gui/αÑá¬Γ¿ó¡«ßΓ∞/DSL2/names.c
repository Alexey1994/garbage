typedef struct {
	Byte name[16];
}
Naming_Operator_Name;


Naming_Operator_Name names_stack[256];
Number               names_stack_length = 0;
//Number               names_queue_index = 0;

void add_name()
{
	copy_bytes(names_stack + names_stack_length, name_value, 16);
	++names_stack_length;
}