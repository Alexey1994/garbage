return function(global, parent, attributes)local outer = {} local self = {__root_children={},
}
DOM_Element(nil, self, parent, ({name=constant('Кнопка'), height=variable(400), width=variable(600), y=variable(0), x=variable(0), id=constant('win')}))
.block().window({height=variable(20), width=variable(180), y=variable(10), x=variable(10), id=constant('button_background')})
.end_block()


self.text = variable('Button')

self.win.window_element.draw.bind({
	set = function(element)
		local display = element.window.begin_draw()
		api.draw_rectangle(display, 0, 0, element.width.get() + 1, element.height.get() + 1, rgb(255, 255, 255))
		element.window.end_draw()
	end
})

self.button_background.window_element.draw.bind({
	set = function(element)
		local display = element.window.begin_draw()
		api.draw_rectangle(display, 0, 0, element.width.get(), element.height.get(), rgb(128, 128, 128))
		local text_width, text_height = api.calculate_text_size(display, self.text.get())
		api.draw_text(display, self.text.get(), (element.width.get() - text_width) / 2, (element.height.get() - text_height) / 2 - 1, rgb(255, 255, 255))
		element.window.end_draw()
	end
})

self.win.window_element.window.show()

local t = 0
while not self.win.window_element.close.get() do
	while api.pop_window_message() ~= 0 do
	end

	Process.sleep(20)
	
	self.text.set('Button' .. (t * t))
	self.button_background.window_element.window.redraw()
	t = t + 1
end
if attributes and attributes.id then global[attributes.id.get()] = outer end
return outer end