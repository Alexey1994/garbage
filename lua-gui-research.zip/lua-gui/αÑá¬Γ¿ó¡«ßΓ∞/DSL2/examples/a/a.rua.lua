function t(global, parent, attributes)local self = {__root_children={},
}
DOM_Element(nil, self, parent, ({name=constant('Жыжка'), height=variable(400), width=variable(600), y=variable(0), x=variable(0), id=constant('t')}))
.block().end_block()DOM_Element(nil, self, parent, ({name=constant('Пыска'), height=variable(200), width=variable(300), y=variable(0), x=variable(0), id=constant('tt')}))
DOM_Element(nil, self, parent, ({name=constant('Вымя'), height=variable(200), width=variable(300), y=variable(0), x=variable(0), id=constant('ttt')}))




self.t.window_element.draw.bind({
	set = function(element)
		local display = element.window.begin_draw()
		api.draw_rectangle(display, 0, 0, element.width.get() + 1, element.height.get() + 1, rgb(255, 255, 255))
		element.window.end_draw()
	end
})

self.tt.window_element.draw.bind({
	set = function(element)
		local display = element.window.begin_draw()
		api.draw_rectangle(display, 0, 0, element.width.get() + 1, element.height.get() + 1, rgb(0, 0, 255))
		api.draw_rectangle(display, 0, 0, 10, 10, rgb(255, 0, 255))
		api.draw_text(display, 'засоска', 20, 20, rgb(0, 255, 255));
		element.window.end_draw()
	end
})

self.ttt.window_element.draw.bind({
	set = function(element)
		local display = element.window.begin_draw()
		api.draw_rectangle(display, 0, 0, element.width.get() + 1, element.height.get() + 1, rgb(255, 0, 255))
		element.window.end_draw()
	end
})

self.t.window_element.window.show()
self.tt.window_element.window.show()
self.ttt.window_element.window.show()

self.tt.window_element.height.bind({
	set = function(t)
		print('change ', t)
	end
})

while not self.t.window_element.close.get() do
	while api.pop_window_message() ~= 0 do
	end
	
	--self.x.set(self.x.get() + 1)

	Process.sleep(20)
end
if attributes and attributes.id then global[attributes.id.get()] = self end
return self end

t()