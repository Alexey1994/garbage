#include <types.c>

Byte*   error_text = 0;
Boolean end_of_file = 0;
Number  line_number = 0;
Number  const_number_value;
Byte    name_value[256];
Byte    const_string_value[256];
Number  level = 0;

#include <stream.c>
#include "token.c"
Token   token;

#include "variable.c"
#include "names.c"
#include "expression.c"


#include "file.c"


Number main()
{
	//print("return function(attributes, parent)");
	//print("self.main = DOM_Element(self, parent, attributes)");
	
	token = read_next_token();
	
	while(token != EOF_TOKEN) {
		if(token == '[') {
			++level;
			
			token = read_next_token();
			print(".block()");
			continue;
		}
		else if(token == ']') {
			if(!level) {
				print_error("отсутствует [");
				return 1;
			}
			
			--level;
			
			token = read_next_token();
			print(".end_block()");
			continue;
		}
		
		parse_expression();
	
		if(error_text || end_of_file) {
			break;
		}
	}
	
	if(level) {
		print_error("отсутствует ]");
		return 1;
	}
	
	if(error_text) {
		return 1;
	}
	
	print("\n");
	
	while(head()) {
		print("%c", head());
		next();
	}
	
	print("\nif attributes and attributes.id then global[attributes.id.get()] = outer end");
	print("\nreturn outer ");
	print("end");
	
	
	
	
	Writer    variables_writer;
	File      variables_file;
	Number    i;
	Variable* variable;
	
	initialize_file_writer(&variables_writer, "variables");

	direct_print(&variables_writer, "return function(global, parent, attributes)");
	direct_print(&variables_writer, "local outer = {} local self = {__root_children={},\n");
	for(i = 0; i < number_of_variables; ++i) {
		variable = variables + i;
		
		if(
			variable->name[0] >= 'a' && variable->name[0] <= 'z'
			|| variable->name[0] >= 'A' && variable->name[0] <= 'Z'
			|| variable->name[0] == '_'
		) {
			//print("\n%s = variable(0)", variable->name);
			direct_print(&variables_writer, "\t%s = attributes and attributes['%s'] or variable(0),\n", variable->name, variable->name);
		}
	}
	direct_print(&variables_writer, "}\n");

	deinitialize_writer(&variables_writer);
	
	return 0;
}