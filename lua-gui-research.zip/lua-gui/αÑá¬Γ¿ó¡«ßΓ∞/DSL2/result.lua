return function(global, parent, attributes)local outer = {} local self = {__root_children={},
}
файл D:\творить\программы2\языки не найден