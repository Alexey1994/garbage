#include <memory.c>
#include <heap.c>


typedef struct {
	Byte   name[16];
	Number index;
	Number value;
	Byte*  string_value;
}
Variable;


Variable variables[256] = {0};
Number number_of_variables;


Variable* find_variable(Byte* name)
{
	Number    i;
	Variable* variable;

	for(i = 0; i < number_of_variables; ++i) {
		variable = variables + i;

		if(!compare_null_terminated_bytes(variable->name, name)) {
			return variable;
		}
	}

	return 0;
}


Variable* find_or_create_variable(Byte* name)
{
	Variable* variable;

	variable = find_variable(name);

	if(!variable) {
		variable = variables + number_of_variables;
		copy_bytes(variable->name, name, 16);
		variable->index = number_of_variables;
		variable->value = 0;
		++number_of_variables;
	}

	return variable;
}


Variable* create_local_variable(Number value)
{
	Variable* variable;

	variable = allocate_memory(sizeof(Variable));
	variable->name[0] = '0';//'\0';
	variable->index = -1;
	variable->value = value;

	return variable;
}


Variable* create_const_value(Number value)
{
	Variable* variable;

	variable = allocate_memory(sizeof(Variable));
	variable->name[0] = '1';//'\0';
	variable->index = -1;
	variable->value = value;

	return variable;
}


Variable* create_const_string_value(Byte* string)
{
	Variable* variable;

	variable = allocate_memory(sizeof(Variable));
	variable->name[0] = '2';
	variable->index = -1;
	variable->string_value = allocate_memory(256);
	copy_bytes(variable->string_value, string, 256);

	return variable;
}


/*
Integer_Number compare_variables(Variable* v1, Variable* v2)
{
	return compare_null_terminated_bytes(v1->name, v2->name);
}*/


Variable* variables_stack[256];
Number    variables_stack_top;