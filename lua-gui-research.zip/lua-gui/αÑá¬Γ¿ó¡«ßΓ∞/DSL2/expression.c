#include <types.c>


typedef struct {
	//Boolean  is_operation;
	Number   operation;
	Byte*    operation_name;
	Variable operand;
}
Postfix_Node;

Postfix_Node postfix_nodes[256];
Number       postfix_nodes_length = 0;

void add_postfix_operation(Number operation, Byte* name)
{
	postfix_nodes[postfix_nodes_length].operation = operation;
	postfix_nodes[postfix_nodes_length].operation_name = name;
	++postfix_nodes_length;
}

void add_postfix_operand(Variable* operand)
{
	postfix_nodes[postfix_nodes_length].operation = 0;
	copy_bytes(&postfix_nodes[postfix_nodes_length].operand, operand, sizeof(Variable));
	++postfix_nodes_length;
}


Number get_prior(Token operation)
{
	switch(operation) {
		//unary
		case UNARY_MINUS_OPERATION: return 7;
		case PRINT_TOKEN: return 2;
		case WINDOW_TOKEN: return 2;
		case NAMED_WINDOW_OPERATION: return 2;
		case NAMING_OPERATION: return 2;

		//binary
		//case '=': return 3;
		case ',': return 2;

		case '+': return 4;
		case '-': return 4;

		case '*': return 5;
		case '/': return 5;
		
		case EQUAL_TOKEN: return 6;
		case NOT_EQUAL_TOKEN: return 6;
		case '<': return 6;
		case LESSER_OR_EQUAL_TOKEN: return 6;
		case '>': return 6;
		case GREATHER_OR_EQUAL_TOKEN: return 6;

		case '(': return 1;
		case '{': return 1;
	}

	print_error("[неизвестная операция ");
	print_token(operation);
	print_error(":%d]", operation);
}


typedef struct {
	Token                        operation;
	Byte*                        name;
	struct Operation_Stack_Node* previouse_node;
}
Operation_Stack_Node;

void parse(Boolean require_operand, Operation_Stack_Node** stack_top);

void add_operation(Operation_Stack_Node** stack_top, Operation_Stack_Node* operation_node, Token operation, Byte* name)
{
	operation_node->operation = operation;
	operation_node->name = name;
	operation_node->previouse_node = *stack_top;
	*stack_top = operation_node;

	parse(1, stack_top);
}


void execute_unary_operation(Token operation, Byte* name)
{
	Variable* left_operand;

	left_operand = variables_stack[--variables_stack_top];

	add_postfix_operand(left_operand);
	add_postfix_operation(operation, name);
	
	variables_stack[variables_stack_top++] = create_local_variable(0);

	if(left_operand->name == '\0' || left_operand->name == '1') {
		free_memory(left_operand);
	}
	
	if(left_operand->name == '2') {
		free_memory(left_operand->string_value);
		free_memory(left_operand);
	}
}


void execute_binary_operation(Token operation, Byte* name)
{
	Variable* left_operand;
	Variable* right_operand;
	
	right_operand = variables_stack[--variables_stack_top];
	left_operand = variables_stack[--variables_stack_top];

	add_postfix_operand(left_operand);
	add_postfix_operand(right_operand);
	add_postfix_operation(operation, name);
	
	variables_stack[variables_stack_top++] = create_local_variable(0);

	if(left_operand->name == '0' || left_operand->name == '1') {
		free_memory(left_operand);
	}
	
	if(left_operand->name == '2') {
		free_memory(left_operand->string_value);
		free_memory(left_operand);
	}

	if(right_operand->name == '0' || right_operand->name == '1') {
		free_memory(right_operand);
	}
	
	if(right_operand->name == '2') {
		free_memory(right_operand->string_value);
		free_memory(right_operand);
	}
}


void execute_operation(Token operation, Byte* name)
{
	Variable* left_operand;
	Variable* right_operand;
	Variable* result;

	switch(operation) {
		case UNARY_MINUS_OPERATION:
		case PRINT_TOKEN:
		case WINDOW_TOKEN:
		case NAMED_WINDOW_OPERATION:
		case '}':
		case NAMING_OPERATION:
			execute_unary_operation(operation, name);
			break;

		case ',':

		case '+':
		case '-':
		case '*':
		case '/':
		
		case EQUAL_TOKEN:
		case NOT_EQUAL_TOKEN:
		case '<':
		case LESSER_OR_EQUAL_TOKEN:
		case '>':
		case GREATHER_OR_EQUAL_TOKEN:
			execute_binary_operation(operation, name);
			break;
		
		//case '=':
		//	break;
	}
}

void parse(Boolean require_operand, Operation_Stack_Node** stack_top)
{
	Number               operand;
	Operation_Stack_Node current_operation;
	//Token                token;

	next_token: {
		//token = read_next_token();

		switch(token) {
			case '(':
				if(!require_operand) {
					break;
				}

				token = read_next_token();
				add_operation(stack_top, &current_operation, '(', 0);
				require_operand = 0;
				break;

			case ')':
				if(require_operand) {
					error_text = "ожидался операнд";
					goto error;
				}
				
				token = read_next_token();

				while(*stack_top && (*stack_top)->operation != '(') {
					execute_operation((*stack_top)->operation, (*stack_top)->name);
					*stack_top = (*stack_top)->previouse_node;
				}

				if(*stack_top) {
					*stack_top = (*stack_top)->previouse_node;
				}
				else {
					error_text = "отсутствует (";
					goto error;
				}

				require_operand = 0;
				goto next_token;
			
			case '{':
				if(!require_operand) {
					break;
				}

				token = read_next_token();
				add_operation(stack_top, &current_operation, '{', 0);
				require_operand = 0;
				break;

			case '}':
				token = read_next_token();

				while(*stack_top && (*stack_top)->operation != '{') {
					execute_operation((*stack_top)->operation, (*stack_top)->name);
					*stack_top = (*stack_top)->previouse_node;
				}

				if(*stack_top) {
					execute_operation('}', 0);
					*stack_top = (*stack_top)->previouse_node;
				}
				else {
					error_text = "отсутствует {";
					goto error;
				}

				require_operand = 0;
				goto next_token;

			/*case NAME_TOKEN:
				token = read_next_token();
				
				if(token == '=') {
					if(require_operand) {
						//print("%s=", name_value);
						
						add_name();
						token = read_next_token();
						add_operation(stack_top, &current_operation, NAMING_OPERATION, names_stack + names_stack_length - 1);
						require_operand = 0;
					}
				}
				else if(token == '{') {
					if(require_operand) {
						add_name();
						add_operation(stack_top, &current_operation, NAMED_WINDOW_OPERATION, names_stack + names_stack_length - 1);
						require_operand = 0;
					}
				}
				else {
					variables_stack[variables_stack_top++] = find_or_create_variable(name_value);
					require_operand = 0;
					goto next_token;
				}
				
				break;*/
			
			case NAME_TOKEN:
				token = read_next_token();
				
				variables_stack[variables_stack_top++] = find_or_create_variable(name_value);
				require_operand = 0;
				goto next_token;

			case CONST_NUMBER_TOKEN:
				variables_stack[variables_stack_top++] = create_const_value(const_number_value);
				require_operand = 0;
				token = read_next_token();
				goto next_token;
			
			case CONST_STRING_TOKEN:
				variables_stack[variables_stack_top++] = create_const_string_value(const_string_value);
				require_operand = 0;
				token = read_next_token();
				goto next_token;
			
			case PRINT_TOKEN:
				if(require_operand) {
					token = read_next_token();
					add_operation(stack_top, &current_operation, PRINT_TOKEN, 0);
					require_operand = 0;
				}
				break;
			
			case WINDOW_TOKEN:
				if(require_operand) {
					token = read_next_token();
					add_operation(stack_top, &current_operation, WINDOW_TOKEN, 0);
					require_operand = 0;
				}
				break;
			
			case NAMING_OPERATION:
				if(require_operand) {
					add_name();
					token = read_next_token();
					add_operation(stack_top, &current_operation, NAMING_OPERATION, names_stack + names_stack_length - 1);
					require_operand = 0;
				}
				break;
			
			case NAMED_WINDOW_OPERATION:
				if(require_operand) {
					add_name();
					token = read_next_token();
					add_operation(stack_top, &current_operation, NAMED_WINDOW_OPERATION, names_stack + names_stack_length - 1);
					require_operand = 0;
				}
				break;

			//case '=':
			case ',':
			case '+':
			case '-':
			case '*':
			case '/':
				if(require_operand) {
					if(token == '-') {
						token = read_next_token();
						add_operation(stack_top, &current_operation, UNARY_MINUS_OPERATION, 0);
						require_operand = 0;
					}
					else {
						error_text = "ожидался операнд";
						goto error;
					}
				}
				else {
					while(*stack_top && get_prior((*stack_top)->operation) >= get_prior(token)) {
						execute_operation((*stack_top)->operation, (*stack_top)->name);
						*stack_top = (*stack_top)->previouse_node;
					}

					Number prev_token = token;
					token = read_next_token();
					add_operation(stack_top, &current_operation, prev_token, 0);
					require_operand = 0;
				}
				break;
			
			case EOF_TOKEN:
				end_of_file = 1;
				break;
		}
	}

	if(require_operand) {
		error_text = "ожидался операнд";
		goto error;
	}

	while(*stack_top) {
		if((*stack_top)->operation == '(') {
			error_text = "отсутствует )";
			goto error;
		}

		//print_error("%c", (*stack_top)->operation);
		execute_operation((*stack_top)->operation, (*stack_top)->name);
		*stack_top = (*stack_top)->previouse_node;
	}

	return;

	error: {
		print_error("[%s], последний токен ", error_text);
		print_token(token);
		*stack_top = 0;
	}
}


void print_prefix_notation2(Number* i)
{
	if(!*i) {
		return;
	}
	
	Postfix_Node* node;
	Byte*         operation_name;
	
	node = postfix_nodes + *i - 1;
	--*i;

	if(node->operation) {
		if(node->operation == '=') {
			
		}
		else {
			switch(node->operation) {
				case UNARY_MINUS_OPERATION: operation_name = "negate"; break;
				case PRINT_TOKEN: operation_name = "printer"; break;
				case WINDOW_TOKEN: {
					if(level) {
						operation_name = ".window";
					}
					else {
						operation_name = "DOM_Element(nil, self, parent, ";
					}
					
					break;
				}
				case NAMED_WINDOW_OPERATION: operation_name = ""; break;
				case '}': operation_name = ""; break;
				case NAMING_OPERATION: operation_name = ""; break;

				case '+': operation_name = "add"; break;
				case '-': operation_name = "sub"; break;
				case '*': operation_name = "mul"; break;
				case '/': operation_name = "div"; break;
					
				case EQUAL_TOKEN: operation_name = "equal"; break;
				case NOT_EQUAL_TOKEN: operation_name = "not_equal"; break;
				case '<': operation_name = "lesser"; break;
				case LESSER_OR_EQUAL_TOKEN: operation_name = "lesser_or_equal"; break;
				case '>': operation_name = "greater"; break;
				case GREATHER_OR_EQUAL_TOKEN: operation_name = "greater_or_equal"; break;
			}
			
			if(node->operation == '}') {
				print("{");
			}
			else if(node->operation == ',') {

			}
			else if(node->operation == NAMING_OPERATION) {
				//--names_stack_length;
				print("%s=", node->operation_name);
				//++names_queue_index;
				//print(".name('%s')", node->operation_name);
			}
			else if(node->operation == NAMED_WINDOW_OPERATION) {
				if(level) {
					print(".component('%s', ", node->operation_name);
				}
				else {
					print("DOM_Element('%s', self, parent, ", node->operation_name);
					//print("components['%s'](global, parent, ", node->operation_name);
				}
			}
			else {
				print("%s(", operation_name);
			}
			
			print_prefix_notation2(i);
			
			if(
				node->operation != UNARY_MINUS_OPERATION
				&& node->operation != PRINT_TOKEN
				&& node->operation != WINDOW_TOKEN
				&& node->operation != NAMED_WINDOW_OPERATION
				&& node->operation != '}'
				&& node->operation != NAMING_OPERATION
			) {
				print(", ");
				print_prefix_notation2(i);
			}
			
			if(node->operation == '}') {
				print("}");
			}
			else if(node->operation == ',') {
				
			}
			else if(node->operation == NAMING_OPERATION) {

			}
			else if(node->operation == NAMED_WINDOW_OPERATION) {
				//if(level) {
				//	print("))");
				//}
				//else {
					print(")");
				//}
			}
			else if(node->operation == WINDOW_TOKEN) {
				if(level) {
					print(")");
				}
				else {
					print("))");
				}
			}
			else {
				print(")");
			}
		}
	}
	else {
		switch(node->operand.name[0]) {
			case '0':
				print_prefix_notation2(i);
				break;
				
			case '1':
				print("variable(%d)", node->operand.value);
				break;
			
			case '2':
				print("constant('%s')", node->operand.string_value);
				break;
				
			default:
				print("self.%s", node->operand.name);
		}
	}
}

void print_prefix_notation()
{
	Number i;

	i = postfix_nodes_length;
	print_prefix_notation2(&i);
	print("\n");
}


void parse_expression()
{
	Operation_Stack_Node* stack_top;

	postfix_nodes_length = 0;
	names_stack_length = 0;
	stack_top = 0;
	parse(1, &stack_top);
	
	print_prefix_notation();
}