#include <memory.c>


typedef enum {
	EOF_TOKEN = 256,
	EQUAL_TOKEN,
	NOT_EQUAL_TOKEN,
	LESSER_OR_EQUAL_TOKEN,
	GREATHER_OR_EQUAL_TOKEN,
	CONST_NUMBER_TOKEN,
	CONST_STRING_TOKEN,
	NUMBER_TYPE_TOKEN,
	NAME_TOKEN,
	
	PRINT_TOKEN,
	WINDOW_TOKEN,
	
	UNARY_MINUS_OPERATION,
	NAMING_OPERATION,
	NAMED_WINDOW_OPERATION
}
Token;


Byte token_names[][16] = {
	"<EOF>",
	"==",
	"!=",
	"<=",
	">=",
	"const number",
	"const string",
	"Number",
	"name",
	
	"print",
	"window"
};


void print_token(Token token)
{
	if(token < 256) {
		print_error("%c", token);
	}
	else {
		print_error("%s", token_names[token - 256]);
	}
}


Token read_next_token()
{
	repeat: {
		switch(head()) {
			case '\n':
				++line_number;
			case '\r':
			case '\t':
			case ' ':
				next();
				goto repeat;
			
			case '-':
				next();
				
				if(head() == '-') {
					do {
						next();
					}
					while(head() && head() != '\n');

					if(!head) {
						return EOF_TOKEN;
					}

					++line_number;
					goto repeat;
				}
				
				return '-';
			
			case '\'':
				next();
				Number i = 0;
				while(head() && head() != '\'') {
					const_string_value[i] = head();
					++i;
					next();
				}
				const_string_value[i] = '\0';
				
				if(head() == '\'') {
					next();
				}
				
				return CONST_STRING_TOKEN;
			
			case '!':
				next();
				
				switch(head()) {
					case '=':
						next();
						return NOT_EQUAL_TOKEN;
					
					default:
						return '!';
				}
				break;
			
			case '=':
				next();
				
				switch(head()) {
					case '=':
						next();
						return EQUAL_TOKEN;
					
					default:
						return '=';
				}
				break;
			
			case '<':
				next();
				
				switch(head()) {
					case '=':
						next();
						return LESSER_OR_EQUAL_TOKEN;
					
					case '>':
						next();
						return EOF_TOKEN;
					
					default:
						return '<';
				}
				break;
			
			case '>':
				next();
				
				switch(head()) {
					case '=':
						next();
						return GREATHER_OR_EQUAL_TOKEN;
					
					default:
						return '>';
				}
				break;
			
			case 'a'...'z':
			case 'A'...'Z':
			case '_': {
				Number i;

				i = 0;
				do {
					name_value[i++] = head();
					next();
				}
				while(head() && (head() >= 'a' && head() <= 'z' || head() >= 'A' && head() <= 'Z' || head() >= '0' && head() <= '9' || head() == '_'));
				name_value[i] = '\0';

				for(i = PRINT_TOKEN - 256; i <= WINDOW_TOKEN - 256; ++i) {
					if(!compare_null_terminated_bytes(token_names[i], name_value)) {
						return i + 256;
					}
				}
				
				while(head() && head() == ' ') {
					next();
				}
				
				switch(head()) {
					case '=':
						next();
						return NAMING_OPERATION;
					
					case '{':
						return NAMED_WINDOW_OPERATION;
				}

				return NAME_TOKEN;
			}

			case '0'...'9': {
				const_number_value = 0;
				do {
					const_number_value = const_number_value * 10 + (head() - '0');
					next();
				}
				while(head() && head() >= '0' && head() <= '9');

				return CONST_NUMBER_TOKEN;
			}
			
			case '#': {
				next();
				
				const_number_value = 0;
				while(head() && (head() >= '0' && head() <= '9' || head() >= 'A' && head() <= 'F')) {
					if(head() >= '0' && head() <= '9') {
						const_number_value = const_number_value * 16 + (head() - '0');
					}
					else {
						const_number_value = const_number_value * 16 + (head() - 'A' + 10);
					}

					next();
				}

				return CONST_NUMBER_TOKEN;
			}
			
			case '\0':
				return EOF_TOKEN;
			
			default: {
				Byte head_character = head();
				next();
				return head_character;
			}
		}
	}
}